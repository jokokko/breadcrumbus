let contracts = {};
(function (ctx) {
    ctx.UriPartHost = "UriPartHost";
    ctx.UriParthPath = "UriParthPath";
    ctx.UriPartSearch = "UriPartSearch";
    ctx.UriPartHash = "UriPartHash";
    ctx.OptionBreadcrumbVertical = "optionBreadcrumbVertical";
    ctx.OptionBreadcrumbHorizontal = "optionBreadcrumbHorizontal";

})(contracts);